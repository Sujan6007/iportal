import axios from 'axios';
const url = "http://localhost:8080/api/roles";
const url1 = "http://localhost:8080/api/role";
 class RolesService{
     getRoles(){
         return axios.get(url);
     }
     addRole(role){
         return axios.post(url1,role);
     }
     deleteRole(id){
         return axios.delete(url+"/"+id)
     }
 }
 export default new RolesService();