import axios from 'axios';
const url = "http://localhost:8080/api/admins";
// const url1 = "http://localhost:8080/api/role";
 class AdminService{
     getAdmin(){
         return axios.get(url);
     }
    //  addRole(role){
    //      return axios.post(url1,role);
    //  }
   
 }
 export default new AdminService();