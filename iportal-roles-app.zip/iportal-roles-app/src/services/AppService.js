import axios from 'axios';
const url = "http://localhost:8080/api/apps";
 class AppsService{
     getApps(){
         return axios.get(url);
     }
 }
 export default new AppsService();