import React from "react";
import RolesService from "../services/RolesService";
import "./RoleComponent.css"
import { Link } from "react-router-dom";
import { Button,Modal} from 'react-bootstrap'; 
import AppsComponent from "./AppsComponent";
import SlideDrawer from "../slideDrawer/SlideDrawer";
import Backdrop from "../slideDrawer/Backdrop";
import { VscAccount,VscCircleSlash } from "react-icons/vsc";

class RoleComponent extends React.Component{
    constructor(props){
        super(props)
        this.state={
            roles:[]
        }
     
    }
    // handleModal(){  
    //     this.setState({show:!this.state.show})  
    //   } 
    componentDidMount(){
        RolesService.getRoles().then((response)=>{
            this.setState({roles:response.data})

        });
    }
    state = { drawerOpen: false }
drawerToggleClickHandler = () => {
    this.setState({
      drawerOpen: !this.state.drawerOpen
    })
  }
backdropClickHandler = () => {
    this.setState({
      drawerOpen: false
    })
  }
    
  
    render(){
        let backdrop;
      if(this.state.drawerOpen){
        backdrop = <Backdrop close={this.backdropClickHandler}/>;
       }
        return(
            <div className="role">
                <br/>
                <p>Home    &gt;   Roles</p>
                 < SlideDrawer show={this.state.drawerOpen} />
           { backdrop }
           {/* < RoleComponent toggle={this.drawerToggleClickHandler} /> */}
                
                <h4 className="heading">Roles</h4>
                <hr></hr>
                <div>
                   {/* <Link to="/addrole"> <button className="btn btn-light btn-sm" >Add Role</button></Link>
                   <Link to=""> <button className="btn btn-light btn-sm"  >Delete Role</button></Link> */}
                   <p style={{fontSize:"13px"}}><Link to="/addrole"><VscAccount></VscAccount></Link>
                   <a> </a>Add Role <a style={{color:"rgb(240, 236, 236)"}}> ii</a> <Link to=""><VscCircleSlash></VscCircleSlash></Link> Delete Role</p>
                </div>
                <br/>  

                
                <table className="table table-hover">
                    <thead>
                        <tr>
                            {/* <td>Id</td> */}
   
                           <td>User roles</td>
                            <td></td>
                            <td>Description</td>
                           
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.roles.map(
                                role =>
                                <tr key={role.id}>
                                    
                                    <td  >< input type = "button" value={role.role} className="heading" onClick={this.drawerToggleClickHandler}/></td>
                                  
                                    <td>:</td>
                                    <td>{role.description}</td>
                                </tr>

                            )
                        }
                    </tbody>
                </table>

            </div>
        )
    }

}
export default RoleComponent;