import React,{useState} from "react";
import { Switch, Route, Link } from "react-router-dom";
import "./Sidebar.css";
// import adminicon from "../img/adminicon.JPG";
export default function Sidebar(){
    return(
        <div>
            
          
  <div class="">

  <nav class="navbar navbar-light bg-light shadow pb-2">
        <a class="navbar-brand" href="">
          {/* <img
            src={process.env.PUBLIC_URL + "adminicon.JPG"}
            width="1"
            height="1"
            class="d-inline-block align-top"
            alt=""
          /> */}
        </a>
        <img src= "/img/adminicon.JPG" alt="pic" ></img>
        <div className="adm"> ADMINISTRATION</div>
        
        <i id="nav-icon" class="fa fa-user ms-auto" aria-hidden="true"></i>
      </nav>
  </div>
  
  <div class="sidebar-container">
  <ul class="sidebar-navigation">
    <br/>
  
    <li>
    
    <Link className="link" to=""><i class="bi bi-house-fill"></i>  Home</Link>
    </li>
    <li>
    <Link to="" className="link" ><i class="bi bi-people-fill"></i>  Users</Link>
    </li>
    
    <li>
    <Link to="" className="link"><i class='fas fa-users'></i>  Groups</Link>
    </li>
    <li>
      <Link to="roles" className="link"><i class="bi bi-person-plus-fill"></i>  Roles </Link>
    </li>
    <li>
    <Link to="" className="link"><i class="bi bi-gear-fill"></i>   Settings </Link>
    </li>
    <br/>
    <br/>
    <hr></hr>
    <li>
    <Link to="" className="link"><i class="fa fa-th-large" aria-hidden="true"></i> Apps admin centers</Link>
    </li>
    <li>
    <Link to="" className="link"><i class='fas fa-user-cog'></i> Impersonate user</Link>
    </li>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <img className="this" src= "/img/this.png" alt="pic" ></img>
    <div>
      
    </div>
  </ul>
</div>



        </div>




/* <div>
<nav class="navbar navbar-light bg-light shadow pb-2">
        <a class="navbar-brand" href="">
          <img
            src={process.env.PUBLIC_URL + "adminicon.JPG"}
            width="28"
            height="28"
            class="d-inline-block align-top"
            alt=""
          />
        </a>
        <p class="pt-3">ADMINISTRATION</p>
        <i id="nav-icon" class="fa fa-user ms-auto" aria-hidden="true"></i>
      </nav>
<nav id="sidebar">
        <ul class="list-unstyled components">
          <li>
            <a href="">
              <i class="fa fa-home ml-3 mr-2 mt-4" aria-hidden="true"></i>Home
            </a>
           
          </li>
          <li class="active">
            <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">
              <i class="fas fa-user-friends ml-3 mr-2"></i>
              users
              <i id="drop" class="fas fa-angle-down"></i>
            </a>
            <ul class="collapse list-unstyled ml-4" id="homeSubmenu">
              <li>
                <Link to={"Activeuserlist"}>Active users</Link>
              </li>
              <li>
                <a href="">Contact</a>
              </li>
              <li>
                <a href="">Deleted Users</a>
              </li>
              <li>
                <a href="">Users settings</a>
              </li>
            </ul>
          </li>
          <li>
            <a
              href="#GroupsSubmenu"
              data-toggle="collapse"
              aria-expanded="false"
            >
              <i class="fas fa-users ml-3 mr-2"></i>
              Groups
              <i id="drop" class="fas fa-angle-down"></i>
            </a>
          </li>
          <li>
          
              <Link to={"/roles"}>Roles</Link>
          
          </li>
          <li class="active">
            <a
              href="#settingsSubmenu"
              data-toggle="collapse"
              aria-expanded="false"
            >
              <i class="fa fa-cog ml-3 mr-2" aria-hidden="true"></i>
              Settings
              <i id="drop" class="fas fa-angle-down"></i>
            </a>
            <ul class="collapse list-unstyled ml-3 mr-2" id="settingsSubmenu">
              <li>
                <a href="">Integrated apps</a>
              </li>
            </ul>
          </li>
        </ul>
        <ul class="list-unstyled ml-3 mr-2">
          <li>
            <a href="">Apps admin centers</a>
          </li>
          <li>
            <a href="">Impersonate user</a>
          </li>
        </ul>
        <img
          src={process.env.PUBLIC_URL + "this.png"}
          width="210"
          height="80"
          class="fix"
          alt=""
        />
      </nav>

      </div> */








  )
}
