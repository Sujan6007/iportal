import logo from './logo.svg';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './App.css';
import RoleComponent from './components/RoleComponent';
import { BrowserRouter as Router, Switch, Route, Routes, Link } from "react-router-dom";
import Sidebar from './components/Sidebar';
import AppsComponent from './components/AppsComponent';
import AddRole from './components/AddRole';
import AdminService from './services/AdminService';
import AdminComponent from './components/AdminComponent';
import Backdrop from './slideDrawer/Backdrop';


function App() {
  return (
   
    <Router>
    <div>
      
    <Sidebar/>
    {/* <RoleComponent/> */}

    
     {/* <Switch>
              <Route exact path="/" component={Sidebar} />
     </Switch> */}
     <Switch>
       {/* <Route exact path="/" component={Sidebar}/> */}
       <Route exact path="/roles" component={RoleComponent}/>
       <Route exact path="/apps" component={AppsComponent}/>
       <Route exact path="/addrole" component={AddRole}/>
       <Route exact path="/admin" component={AdminComponent}/>
       <Route exact path="/back" component={Backdrop}/>


     </Switch>
     {/* <Routes>
     <Route exact path="/roles" component={RoleComponent}/>
     </Routes> */}
  
    </div>
    </Router>

  );
}

export default App;
