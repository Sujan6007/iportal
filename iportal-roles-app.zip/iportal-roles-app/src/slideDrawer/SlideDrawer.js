import React from 'react'
import './SlideDrawer.css'
import AppService from '../services/AppService'
import AppsComponent from '../components/AppsComponent'
import { Link } from 'react-router-dom'
import RolesService from '../services/RolesService'
import RoleComponent from '../components/RoleComponent'
import Collapsible from 'react-collapsible';
import AdminService from '../services/AdminService'


import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
// import * as React from 'react';
export default class SlideDrawer extends React.Component {
   constructor(props){
      super(props)
      this.state={
          apps:[],
          admins:[],
          selected: 'Application Access'
      }
     
  }
  componentDidMount(){
      AppService.getApps().then((response)=>{
          this.setState({apps:response.data})

      });
       AdminService.getAdmin().then((response)=>{
            this.setState({admins:response.data})

        });
  }
//   setSelected=(tab) => {
//       this.setState({selected:tab})
//   }
 


   render(){
       let drawerClasses = 'side-drawer'
       if(this.props.show) {
          drawerClasses = 'side-drawer open'
       }
       return(

   
          <div className={drawerClasses}>
               <h2 >&ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; &ensp; <Link className='arrow'><i class="bi bi-arrow-left"></i> </Link> <Link className='arrow' to="/roles"><i class="bi bi-x"></i></Link></h2>

              <br/>
              <br/>
              <br/>
        
              <Tabs>
    <TabList className="tab">
      <Tab>Application Access</Tab>
      <Tab>Assigned Admins</Tab>
    </TabList>

    <TabPanel>
    <div className="Apps">
      
      <table className="table table-hover">
          <thead>
              <tr>
                  {/* <td>Id</td> */}
                  <td>Application Access</td>
                  <td></td>
                  
                 
              </tr>
          </thead>
          <tbody>
              {
                  this.state.apps.map(
                      app =>
                      <tr key={app.id}>
                          {/* <td>{role.id}</td> */}
                          <td><i class='fas fa-check'   ></i> {app.app}</td>

                      </tr>

                  )
              }
          </tbody>
      </table>

  </div>
    </TabPanel>
    <TabPanel>
    <div className="Admin">
    <Link className='link'>+ Add Admin</Link>
                
                <table className="table table-hover">
                    
                    <thead>
                        <tr>
                            {/* <td>Id</td> */}
                            <td>Admin</td>
                            <td>Last sign-in</td>
                            <td></td>
                            
                           
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.admins.map(
                                admin =>
                                <tr key={admin.id}>
                                    {/* <td>{role.id}</td> */}
                                    <td>{admin.admin}</td>
                                    <td>{admin.last_seen}</td>
    
                                </tr>

                            )
                        }
                    </tbody>
                </table>

            </div>
      
    </TabPanel>
  </Tabs>
                 
             
            
             
          </div>
          )
        }}
        
         
