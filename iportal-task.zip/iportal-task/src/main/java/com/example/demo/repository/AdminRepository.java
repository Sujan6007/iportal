package com.example.demo.repository;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Admin;




@EnableJpaRepositories
@Repository
public interface AdminRepository extends JpaRepository<Admin, Long> {
//	List<Admin> findByAdmin(String admin);
//	List<Admin> findByLastSeen(Date last_seen);

}
