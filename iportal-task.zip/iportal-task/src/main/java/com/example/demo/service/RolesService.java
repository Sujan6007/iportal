//package com.example.demo.service;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.demo.model.Roles;
//import com.example.demo.repository.RoleRepository;
//
//@Service
//public class RolesService {
//	@Autowired
//	RoleRepository repo;
//	public void store(Roles role) {
//		repo.save(role);
//		
//	}
//
//	public List<Roles> getRoles() {
//		List<Roles> list=repo.findAll();
//
//		return list;
//	}
//	public List<Roles> fetchRoles(String role, String description) {
//        // TODO Auto-generated method stub
//		return repo.findByRoleAndDescription(role, description);
//    }
//
//}
