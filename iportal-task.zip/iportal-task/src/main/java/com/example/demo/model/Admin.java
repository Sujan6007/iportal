package com.example.demo.model;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "admin")

public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "admin")
	private String admin;
	@Column(name = "last_sign_in")
	private String last_seen ;
	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Admin( String admin, String last_seen) {
		super();
		
		this.admin = admin;
		this.last_seen = last_seen;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAdmin() {
		return admin;
	}
	public void setAdmin(String admin) {
		this.admin = admin;
	}
	public String getLast_seen() {
		return last_seen;
	}
	public void setLast_seen(String last_seen) {
		this.last_seen = last_seen;
	}

	@Override
	public String toString() {
		return "Admin [id=" + id + ", admin=" + admin + ", last_seen=" + last_seen + "]";
	}
	
	
	
	
}