package com.example.demo.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Roles;
import com.example.demo.repository.AdminRepository;
import com.example.demo.model.Admin;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api")

public class AdminController {
	 @Autowired
	  AdminRepository adminRepository;
	 
	 @PostMapping("/admin")
	  public ResponseEntity<Admin> createAdmins(@RequestBody Admin admin) {
	    try {
	     Admin admins = adminRepository.save(admin);
//	    		 .save(new Admin(admin.getAdmin(), admin.getLast_seen()));
	    		 
	      return new ResponseEntity<>(admins, HttpStatus.CREATED);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	  @GetMapping("/admins")
	  public ResponseEntity<List<Admin>> getAllTutorials(@RequestParam(required = false) String admin) {
	    try {
	      List<Admin> admins = new ArrayList<Admin>();
	      if (admin == null)
	        adminRepository.findAll().forEach(admins::add);
//	      else
//	        adminRepository.findByAdmin(admin).forEach(admins::add);
	      if (admins.isEmpty()) {
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	      }
	      return new ResponseEntity<>(admins, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    
	  }
	  @DeleteMapping("/admin/{id}")
	  public ResponseEntity<HttpStatus> deleteRole(@PathVariable("id") long id) {
	    try {
	      adminRepository.deleteById(id);
	      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    } catch (Exception e) {
	      return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	

}
